import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import java.util.concurrent.locks.ReentrantLock;

/** Q5 - compare synchronization strategies for 10,000 bookings (8 worker threads). */
public class Strategies {
    static volatile long sink;
    static long work() { long x = 0; for (int i = 0; i < 2000; i++) x += i * 31L; return x; }   // pricing/validation, not shared

    interface Booker { boolean book(int seat); int sold(); }

    static class SyncMethod implements Booker {
        boolean[] b; int sold; SyncMethod(int n) { b = new boolean[n]; }
        synchronized public boolean book(int s) { sink = work(); if (!b[s]) { b[s] = true; sold++; return true; } return false; }
        public int sold() { return sold; }
    }
    static class SyncBlock implements Booker {
        boolean[] b; int sold; final Object lock = new Object(); SyncBlock(int n) { b = new boolean[n]; }
        public boolean book(int s) { sink = work(); synchronized (lock) { if (!b[s]) { b[s] = true; sold++; return true; } } return false; }
        public int sold() { return sold; }
    }
    static class Atomic implements Booker {
        AtomicBoolean[] b; AtomicInteger sold = new AtomicInteger(); Atomic(int n) { b = new AtomicBoolean[n]; for (int i = 0; i < n; i++) b[i] = new AtomicBoolean(); }
        public boolean book(int s) { sink = work(); if (b[s].compareAndSet(false, true)) { sold.incrementAndGet(); return true; } return false; }
        public int sold() { return sold.get(); }
    }
    static class Lock implements Booker {
        boolean[] b; int sold; final ReentrantLock l = new ReentrantLock(); Lock(int n) { b = new boolean[n]; }
        public boolean book(int s) { sink = work(); l.lock(); try { if (!b[s]) { b[s] = true; sold++; return true; } return false; } finally { l.unlock(); } }
        public int sold() { return sold; }
    }
    static class CHM implements Booker {
        ConcurrentHashMap<Integer,Boolean> m = new ConcurrentHashMap<>();
        public boolean book(int s) { sink = work(); return m.putIfAbsent(s, true) == null; }
        public int sold() { return m.size(); }
    }

    static double run(Booker bk, int bookings, int seats) throws Exception {
        ExecutorService ex = Executors.newFixedThreadPool(8);
        long t0 = System.nanoTime();
        CountDownLatch done = new CountDownLatch(bookings);
        for (int i = 0; i < bookings; i++) { final int s = i % seats; ex.execute(() -> { bk.book(s); done.countDown(); }); }
        done.await(); long t = System.nanoTime() - t0; ex.shutdown();
        return t / 1e6;
    }
    public static void main(String[] a) throws Exception {
        int B = 10_000, SEATS = 500;     // 10,000 booking requests competing for 500 seats
        String[] names = {"synchronized method", "synchronized block", "AtomicBoolean[] CAS", "ReentrantLock", "ConcurrentHashMap"};
        for (int w = 0; w < 2; w++) run(new SyncMethod(SEATS), B, SEATS);   // warm up
        System.out.printf("%-22s %10s %8s %s%n", "strategy", "avg ms", "sold", "(5 runs, 10,000 bookings, 500 seats)");
        for (int k = 0; k < names.length; k++) {
            double sum = 0; int sold = 0;
            for (int r = 0; r < 5; r++) {
                Booker bk = k == 0 ? new SyncMethod(SEATS) : k == 1 ? new SyncBlock(SEATS) : k == 2 ? new Atomic(SEATS) : k == 3 ? new Lock(SEATS) : new CHM();
                sum += run(bk, B, SEATS); sold = bk.sold();
            }
            System.out.printf("%-22s %10.1f %8d%n", names[k], sum / 5, sold);
        }
    }
}
