import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.logging.*;

/** Q3 - Daily sales report: naive manual close, correct manual finally, and try-with-resources. */
public class ReportGenerator {
    static final Logger LOG = Logger.getLogger("report");
    static final AtomicInteger OPEN = new AtomicInteger();   // number of handles currently open
    static final AtomicInteger PEAK = new AtomicInteger();

    /** Reader that counts itself as open/closed so leaks can be measured. */
    static class TReader extends BufferedReader {
        final String name; boolean closed; final boolean failOnClose;
        TReader(String f, boolean failOnClose) throws IOException {
            super(new FileReader(f)); name = f; this.failOnClose = failOnClose;
            PEAK.accumulateAndGet(OPEN.incrementAndGet(), Math::max);
        }
        @Override public void close() throws IOException {
            if (!closed) { closed = true; OPEN.decrementAndGet(); }
            super.close();
            if (failOnClose) throw new IOException("close() failed for " + name);
        }
    }
    static class TWriter extends PrintWriter {
        TWriter(String f) throws IOException { super(new FileWriter(f)); PEAK.accumulateAndGet(OPEN.incrementAndGet(), Math::max); }
        boolean closed;
        @Override public void close() { if (!closed) { closed = true; OPEN.decrementAndGet(); } super.close(); }
    }

    static double sumFile(BufferedReader r, String name) throws IOException {
        double total = 0; String line;
        while ((line = r.readLine()) != null) {
            try { total += Double.parseDouble(line.trim()); }
            catch (NumberFormatException e) { LOG.severe("Bad line in " + name + ": '" + line + "'"); throw e; }
        }
        return total;
    }

    // ---- Version 1: NAIVE manual - close() is inside try, not in finally (typical leak) ----
    static void v1Naive(String[] files, String out) throws IOException {
        TWriter w = new TWriter(out);
        for (String f : files) {
            TReader r = new TReader(f, false);
            double t = sumFile(r, f);
            w.println(f + "," + t);
            r.close();                      // skipped when sumFile throws
        }
        w.close();                          // skipped when anything throws
    }

    // ---- Version 2: correct manual - try/catch/finally with nested close handling ----
    static void v2Finally(String[] files, String out) throws IOException {
        TWriter w = null;
        try {
            w = new TWriter(out);
            for (String f : files) {
                TReader r = null;
                try {
                    r = new TReader(f, false);
                    w.println(f + "," + sumFile(r, f));
                } finally {
                    if (r != null) { try { r.close(); } catch (IOException ignore) { } }
                }
            }
        } finally {
            if (w != null) w.close();
        }
    }

    // ---- Version 3: try-with-resources ----
    static void v3Twr(String[] files, String out) throws IOException {
        try (TWriter w = new TWriter(out)) {
            for (String f : files) {
                try (TReader r = new TReader(f, false)) {
                    w.println(f + "," + sumFile(r, f));
                }
            }
        }
    }

    interface Gen { void run(String[] files, String out) throws IOException; }

    static String attempt(String label, Gen g, String[] files, String out) {
        OPEN.set(0); PEAK.set(0);
        String status = "OK";
        try { g.run(files, out); } catch (Exception e) { status = "FAILED (" + e.getClass().getSimpleName() + ")"; }
        System.out.printf("%-28s %-34s files left open: %d   peak open: %d%n", label, status, OPEN.get(), PEAK.get());
        return status;
    }

    public static void main(String[] args) throws Exception {
        Path dir = Files.createTempDirectory("sales");
        String[] good = new String[5], bad = new String[5];
        for (int i = 0; i < 5; i++) {
            good[i] = dir.resolve("store" + (i + 1) + ".txt").toString();
            Files.writeString(Path.of(good[i]), "100.5\n200\n" + (i * 10) + "\n");
        }
        bad = good.clone();
        bad[2] = dir.resolve("store3_corrupt.txt").toString();      // corrupt file in the middle
        Files.writeString(Path.of(bad[2]), "50\nabc\n70\n");

        System.out.println("=== Same VALID input: do the versions agree? ===");
        String o1 = dir.resolve("r1.csv").toString(), o2 = dir.resolve("r2.csv").toString(), o3 = dir.resolve("r3.csv").toString();
        attempt("V1 naive manual", ReportGenerator::v1Naive, good, o1);
        attempt("V2 manual try/finally", ReportGenerator::v2Finally, good, o2);
        attempt("V3 try-with-resources", ReportGenerator::v3Twr, good, o3);
        String a = Files.readString(Path.of(o1)), b = Files.readString(Path.of(o2)), c = Files.readString(Path.of(o3));
        System.out.println("Report text:\n" + c);
        System.out.println("V1 == V2 : " + a.equals(b) + "   V2 == V3 : " + b.equals(c));

        System.out.println("\n=== Same FAILING input (store3 is corrupt) ===");
        LOG.setUseParentHandlers(false);
        Handler h = new StreamHandler(System.out, new SimpleFormatter() {
            @Override public String format(LogRecord r) { return "  [LOG " + r.getLevel() + "] " + r.getMessage() + "\n"; } });
        h.setLevel(Level.ALL); LOG.addHandler(h);
        attempt("V1 naive manual", ReportGenerator::v1Naive, bad, o1);   h.flush();
        attempt("V2 manual try/finally", ReportGenerator::v2Finally, bad, o2); h.flush();
        attempt("V3 try-with-resources", ReportGenerator::v3Twr, bad, o3);  h.flush();

        System.out.println("\n=== Suppressed exception demo (close() also fails) ===");
        try (TReader r = new TReader(good[0], true)) {
            throw new IllegalStateException("processing failed");
        } catch (Exception e) {
            System.out.println("Primary   : " + e);
            for (Throwable s : e.getSuppressed()) System.out.println("Suppressed: " + s);
        }

        System.out.println("\n=== Manual finally: close() exception MASKS the original ===");
        try {
            TReader r = null;
            try { r = new TReader(good[0], true); throw new IllegalStateException("processing failed"); }
            finally { if (r != null) r.close(); }
        } catch (Exception e) { System.out.println("Caller sees: " + e + "   (original exception lost, suppressed=" + e.getSuppressed().length + ")"); }

        System.out.println("\n=== Closing order with try-with-resources ===");
        class R implements AutoCloseable { String n; R(String n){this.n=n; System.out.println("open  " + n);} public void close(){ System.out.println("close " + n);} }
        try (R r1 = new R("A-reader"); R r2 = new R("B-writer")) { System.out.println("body"); }
    }
}
