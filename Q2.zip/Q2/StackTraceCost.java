/** Q2 Alternative: cost of capturing a stack trace vs call depth, and memory held by chained exceptions. */
public class StackTraceCost {
    static class Heavy extends Exception { Heavy(String m, Throwable c) { super(m, c); } }
    static class Light extends Exception { Light(String m) { super(m, null, false, false); } }
    static void recurse(int depth, boolean light) throws Exception {
        if (depth == 0) { if (light) throw new Light("x"); else throw new Heavy("x", null); }
        recurse(depth - 1, light);
    }
    public static void main(String[] a) throws Exception {
        int[] depths = {5, 50, 500};
        for (int d : depths) {
            int N = d >= 500 ? 20000 : 100000;
            for (int w = 0; w < 3000; w++) { try { recurse(d, false); } catch (Exception e) {} }
            long t0 = System.nanoTime();
            for (int i = 0; i < N; i++) { try { recurse(d, false); } catch (Exception e) {} }
            long t1 = System.nanoTime();
            for (int i = 0; i < N; i++) { try { recurse(d, true); } catch (Exception e) {} }
            long t2 = System.nanoTime();
            System.out.printf("depth %4d : with stack trace %9.0f ns   without %7.0f ns%n", d, (t1 - t0) / (double) N, (t2 - t1) / (double) N);
        }
        // memory held by a chain of k exceptions each capturing depth-50 stack trace
        for (int k : new int[]{1, 10, 100}) {
            System.gc(); long before = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
            Throwable[] keep = new Throwable[2000];
            for (int j = 0; j < keep.length; j++) {
                Throwable t = null;
                try { t = build(k, 50); } catch (Throwable x) { t = x; }
                keep[j] = t;
            }
            System.gc(); long after = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
            System.out.printf("chain length %3d : ~%6d bytes per chain (2000 chains retained)%n", k, (after - before) / keep.length);
            if (keep[0] == null) System.out.println();
        }
    }
    static Throwable build(int k, int depth) {
        if (depth > 0) return build(k, depth - 1);
        Throwable t = new Exception("root");
        for (int i = 1; i < k; i++) t = new Exception("wrap" + i, t);
        return t;
    }
}
