import java.io.IOException;

/** Q2 - Online Examination Portal: controller -> service -> storage with a user-defined exception hierarchy. */
public class ExamPortal {
    public static void main(String[] args) {
        Controller c = new Controller(new Service(new Store()));
        System.out.println("S0 valid submission");
        c.submit("21CS001", "CSA09", "ans.pdf", 120, 55);
        System.out.println("\nS1 exam window closed (minute 130 of 120)");
        c.submit("21CS001", "CSA09", "ans.pdf", 120, 130);
        System.out.println("\nS2 student not registered");
        c.submit("99XX999", "CSA09", "ans.pdf", 120, 55);
        System.out.println("\nS3 answer file too large (900 KB > 300 KB limit)");
        c.submit("21CS001", "CSA09", "big.pdf", 900, 55);
        System.out.println("\nS4 storage failure (disk full) - chained cause");
        c.submit("21CS001", "CSA09", "full.pdf", 100, 55);
        System.out.println("\nS5 programming error - unchecked (null student id)");
        try { c.submit(null, "CSA09", "ans.pdf", 10, 5); }
        catch (ExamConfigException e) { System.out.println("  UNCHECKED escaped to caller: " + e.getMessage()); }

        System.out.println("\n===== Full chained stack trace for S4 =====");
        try { new Service(new Store()).process("21CS001", "CSA09", "full.pdf", 100, 55); }
        catch (ExamException e) { e.printStackTrace(System.out); }

        System.out.println("\n===== getCause() walk =====");
        try { new Store().save("full.pdf"); }
        catch (SubmissionStorageException e) {
            Throwable t = e; int level = 0;
            while (t != null) { System.out.println("  level " + level++ + ": " + t.getClass().getName() + " : " + t.getMessage()); t = t.getCause(); }
        }

        System.out.println("\n===== Re-thrown WITHOUT cause (information lost) =====");
        try { new BrokenStore().save("full.pdf"); }
        catch (SubmissionStorageException e) {
            e.printStackTrace(System.out);
            System.out.println("  getCause() = " + e.getCause());
        }
    }
}

class Controller {
    private final Service service;
    Controller(Service s) { service = s; }
    void submit(String id, String course, String file, long kb, int minute) {
        try {
            service.process(id, course, file, kb, minute);
            System.out.println("  Student sees: Submission received.");
        } catch (ExamClosedException e) {
            System.out.println("  Student sees: The exam window has closed. (log: " + e.getMessage() + ")");
        } catch (NotRegisteredException e) {
            System.out.println("  Student sees: You are not registered for this course.");
        } catch (FileTooLargeException e) {
            System.out.println("  Student sees: Your file is too large. Maximum is 300 KB.");
        } catch (SubmissionStorageException e) {          // handled finally HERE (top of the stack)
            System.out.println("  Student sees: We could not save your answer. Please retry. (support ref logged)");
            System.out.println("  [log] " + e.getMessage() + " | root cause: " + e.getCause().getMessage());
        } catch (ExamException e) {                        // safety net for future subclasses
            System.out.println("  Student sees: Submission failed.");
        }
    }
}

class Service {
    private final Store store;
    Service(Store s) { store = s; }
    void process(String id, String course, String file, long kb, int minute) throws ExamException {
        if (id == null) throw new ExamConfigException("studentId must not be null");   // unchecked
        if (minute > 120) throw new ExamClosedException("Window closed at minute 120, submission at " + minute);
        if (!id.startsWith("21")) throw new NotRegisteredException(id + " is not registered for " + course);
        if (kb > 300) throw new FileTooLargeException(file + " is " + kb + " KB, limit 300 KB");
        store.save(file);                                                              // propagates upward
    }
}

class Store {
    void save(String file) throws SubmissionStorageException {
        try {
            lowLevelWrite(file);
        } catch (IOException e) {
            throw new SubmissionStorageException("Could not store " + file, e);        // chaining
        }
    }
    void lowLevelWrite(String file) throws IOException {
        if (file.startsWith("full")) throw new IOException("No space left on device");
        System.out.println("  [storage] wrote " + file);
    }
}

class BrokenStore extends Store {
    @Override void save(String file) throws SubmissionStorageException {
        try { lowLevelWrite(file); }
        catch (IOException e) { throw new SubmissionStorageException("Could not store " + file, null); } // cause dropped!
    }
}

class ExamException extends Exception {
    ExamException(String m) { super(m); }
    ExamException(String m, Throwable cause) { super(m, cause); }
}
class ExamClosedException extends ExamException { ExamClosedException(String m) { super(m); } }
class NotRegisteredException extends ExamException { NotRegisteredException(String m) { super(m); } }
class FileTooLargeException extends ExamException { FileTooLargeException(String m) { super(m); } }
class SubmissionStorageException extends ExamException { SubmissionStorageException(String m, Throwable c) { super(m, c); } }
class ExamConfigException extends RuntimeException { ExamConfigException(String m) { super(m); } }  // unchecked: programming error
