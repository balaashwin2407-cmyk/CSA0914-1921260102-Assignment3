import java.io.*;
import java.lang.management.*;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import java.util.stream.*;

/**
 * Q7 - Semester result processing: ExecutorService + Callable + Future,
 * ConcurrentHashMap for results, one failure never stops the run.
 *
 * Score file format (one line):  studentId,m1,m2,m3,m4,m5   (each mark an integer 0..100)
 */
public class ResultProcessor {
    enum Status { OK, CORRUPT, MISSING, ERROR }
    record FileResult(String file, Status status, String detail, int total) {}

    static class CorruptFileException extends Exception { CorruptFileException(String m) { super(m); } }

    static volatile int LATENCY_MS = 0;                 // simulated per-file disk/network latency
    static final Set<String> BUG_FILES = ConcurrentHashMap.newKeySet();   // injected unexpected bug

    /** Reads, validates and scores one file. Throws checked exceptions for expected problems. */
    static FileResult processOne(Path p) throws IOException, CorruptFileException {
        if (LATENCY_MS > 0) { try { Thread.sleep(LATENCY_MS); } catch (InterruptedException e) { Thread.currentThread().interrupt(); } }
        if (BUG_FILES.contains(p.getFileName().toString())) throw new IllegalStateException("injected bug");
        String line;
        try (BufferedReader r = Files.newBufferedReader(p)) { line = r.readLine(); }   // NoSuchFileException if missing
        if (line == null) throw new CorruptFileException("empty file");
        String[] f = line.split(",");
        if (f.length != 6) throw new CorruptFileException("expected 6 fields, got " + f.length);
        int total = 0;
        for (int i = 1; i < 6; i++) {
            int m;
            try { m = Integer.parseInt(f[i].trim()); } catch (NumberFormatException e) { throw new CorruptFileException("non-numeric mark '" + f[i] + "'"); }
            if (m < 0 || m > 100) throw new CorruptFileException("mark out of range: " + m);
            total += m;
        }
        return new FileResult(p.getFileName().toString(), Status.OK, "total=" + total, total);
    }

    /** The Callable never lets an expected failure escape: it converts it into a FileResult. */
    static Callable<FileResult> task(Path p) {
        return () -> {
            try { return processOne(p); }
            catch (NoSuchFileException e)   { return new FileResult(p.getFileName().toString(), Status.MISSING, "file not found", 0); }
            catch (CorruptFileException e)  { return new FileResult(p.getFileName().toString(), Status.CORRUPT, e.getMessage(), 0); }
            catch (IOException e)           { return new FileResult(p.getFileName().toString(), Status.ERROR, "I/O: " + e, 0); }
            // anything else (unexpected bug) escapes the Callable and is caught via Future.get() below
        };
    }

    static class Summary {
        final ConcurrentHashMap<String, FileResult> results = new ConcurrentHashMap<>();   // shared results (thread safe)
        final Map<Status, LongAdder> counts = new EnumMap<>(Status.class);
        long okTotalMarks;
        Summary() { for (Status s : Status.values()) counts.put(s, new LongAdder()); }
        void add(FileResult r) { results.put(r.file(), r); counts.get(r.status()).increment(); }
        long count(Status s) { return counts.get(s).sum(); }
        String line() { return "OK=" + count(Status.OK) + " CORRUPT=" + count(Status.CORRUPT) + " MISSING=" + count(Status.MISSING) + " ERROR=" + count(Status.ERROR) + " | recorded=" + results.size(); }
    }

    static Summary runExecutor(List<Path> files, int pool) throws Exception {
        ExecutorService ex = Executors.newFixedThreadPool(pool);
        List<Future<FileResult>> fs = new ArrayList<>();
        List<Path> order = new ArrayList<>(files);
        for (Path p : files) fs.add(ex.submit(task(p)));
        Summary sum = new Summary();
        for (int i = 0; i < fs.size(); i++) {
            String name = order.get(i).getFileName().toString();
            try { sum.add(fs.get(i).get()); }
            catch (ExecutionException e) { sum.add(new FileResult(name, Status.ERROR, "unexpected: " + e.getCause(), 0)); }   // one bad task never stops the run
        }
        ex.shutdown(); ex.awaitTermination(1, TimeUnit.MINUTES);
        return sum;
    }

    // ------------ test data ------------
    static List<Path> generate(Path dir, int n, int[] expect) throws IOException {
        List<Path> list = new ArrayList<>(); Random rnd = new Random(42);
        for (int i = 0; i < n; i++) {
            Path p = dir.resolve("score" + i + ".csv"); list.add(p);
            if (i % 33 == 5) { expect[2]++; continue; }                                   // missing (not created)
            if (i % 20 == 7) {                                                            // corrupt variants
                String bad = switch (i % 3) { case 0 -> "S" + i + ",abc,50,60,70,80"; case 1 -> "S" + i + ",50,60"; default -> "S" + i + ",50,60,70,80,150"; };
                Files.writeString(p, bad); expect[1]++; continue;
            }
            Files.writeString(p, "S" + i + "," + rnd.nextInt(101) + "," + rnd.nextInt(101) + "," + rnd.nextInt(101) + "," + rnd.nextInt(101) + "," + rnd.nextInt(101));
            expect[0]++;
        }
        return list;
    }

    static void handChecked(Path dir) throws Exception {
        System.out.println("=== Hand-checked set: 11 files ===");
        List<Path> l = new ArrayList<>();
        for (int i = 0; i <= 6; i++) { Path p = dir.resolve("h" + i + ".csv"); Files.writeString(p, "S" + i + ",10,20,30,40,50"); l.add(p); }     // 7 valid, total 150 each
        Path c1 = dir.resolve("h7.csv"); Files.writeString(c1, "S7,xx,20,30,40,50"); l.add(c1);        // corrupt: non-numeric
        Path c2 = dir.resolve("h8.csv"); Files.writeString(c2, "S8,10,20,30,40,101"); l.add(c2);       // corrupt: out of range
        l.add(dir.resolve("h9.csv"));                                                                   // missing
        Path bug = dir.resolve("h10.csv"); Files.writeString(bug, "S10,1,2,3,4,5"); l.add(bug); BUG_FILES.add("h10.csv");   // injected bug => ERROR
        Summary s = runExecutor(l, 4);
        long marks = s.results.values().stream().filter(r -> r.status() == Status.OK).mapToLong(FileResult::total).sum();
        System.out.println("Expected : OK=7 CORRUPT=2 MISSING=1 ERROR=1 | recorded=11, total marks of OK files = 1050");
        System.out.println("Actual   : " + s.line() + ", total marks of OK files = " + marks);
        s.results.values().stream().filter(r -> r.status() != Status.OK).sorted(Comparator.comparing(FileResult::file))
                .forEach(r -> System.out.println("   " + r.file() + " -> " + r.status() + " (" + r.detail() + ")"));
        BUG_FILES.clear();
    }

    static double median(List<Double> v) { Collections.sort(v); return v.get(v.size() / 2); }

    public static void main(String[] args) throws Exception {
        Path dir = Files.createTempDirectory("results");
        System.out.println("CPU cores visible to JVM: " + Runtime.getRuntime().availableProcessors());
        handChecked(dir);

        int N = 10_000; int[] expect = new int[3];
        Path big = Files.createDirectory(dir.resolve("big"));
        List<Path> files = generate(big, N, expect);
        System.out.println("\n=== " + N + " files generated: expected OK=" + expect[0] + " CORRUPT=" + expect[1] + " MISSING=" + expect[2] + " ===");

        int[] pools = {1, 2, 4, 8, 16, 64};
        for (int latency : new int[]{0, 1}) {
            LATENCY_MS = latency;
            System.out.println("\n--- Executor, simulated latency per file = " + latency + " ms (median of " + (latency == 0 ? 5 : 3) + " runs) ---");
            System.out.printf("%-6s %10s   %s%n", "pool", "time (ms)", "summary");
            for (int p : pools) {
                List<Double> ts = new ArrayList<>(); Summary last = null;
                int reps = latency == 0 ? 5 : 3;
                for (int r = 0; r < reps + (p == 1 && latency == 0 ? 2 : 0); r++) {      // extra warm-up runs for the very first measurement
                    long t0 = System.nanoTime(); last = runExecutor(files, p); ts.add((System.nanoTime() - t0) / 1e6);
                }
                System.out.printf("%-6d %10.0f   %s %s%n", p, median(ts), last.line(),
                        (last.count(Status.OK) == expect[0] && last.count(Status.CORRUPT) == expect[1] && last.count(Status.MISSING) == expect[2]) ? "[correct]" : "[WRONG]");
            }
        }

        // ---------- alternatives ----------
        LATENCY_MS = 1;
        System.out.println("\n=== Alternative 1: parallelStream (common ForkJoinPool), 1 ms latency ===");
        System.out.println("ForkJoin common pool parallelism = " + ForkJoinPool.commonPool().getParallelism());
        long t0 = System.nanoTime(); Summary ps = new Summary();
        files.parallelStream().map(p -> { try { return task(p).call(); } catch (Exception e) { return new FileResult(p.getFileName().toString(), Status.ERROR, e.toString(), 0); } }).forEach(ps::add);
        System.out.printf("time %d ms, %s%n", (System.nanoTime() - t0) / 1_000_000, ps.line());
        BUG_FILES.add("score100.csv");
        try {
            files.parallelStream().map(p -> { try { return processOne(p); } catch (NoSuchFileException | CorruptFileException e) { return new FileResult(p.getFileName().toString(), Status.CORRUPT, "", 0); } catch (IOException e) { throw new UncheckedIOException(e); } }).count();
            System.out.println("parallelStream with an uncaught bug in one lambda: finished");
        } catch (RuntimeException e) { System.out.println("parallelStream with ONE uncaught bug inside the lambda: whole pipeline aborted -> " + e); }
        BUG_FILES.clear();

        System.out.println("\n=== Alternative 2: one thread per file (10,000 threads), 1 ms latency ===");
        ThreadMXBean mx = ManagementFactory.getThreadMXBean(); mx.resetPeakThreadCount();
        long m0 = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        t0 = System.nanoTime(); Summary ts = new Summary();
        List<Thread> threads = new ArrayList<>();
        for (Path p : files) { Thread t = new Thread(() -> { try { ts.add(task(p).call()); } catch (Exception e) { ts.add(new FileResult(p.getFileName().toString(), Status.ERROR, e.toString(), 0)); } }); threads.add(t); t.start(); }
        for (Thread t : threads) t.join();
        System.out.printf("time %d ms, %s, PEAK live threads = %d%n", (System.nanoTime() - t0) / 1_000_000, ts.line(), mx.getPeakThreadCount());
        System.out.println("approx. reserved stack = peak threads x 1 MB (default -Xss on 64-bit Linux) = " + mx.getPeakThreadCount() + " MB virtual");
    }
}
