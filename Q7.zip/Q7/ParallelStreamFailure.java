import java.util.*;
import java.util.stream.*;
/** Q7 Alternative: one uncaught exception inside a parallelStream lambda aborts the whole pipeline. */
public class ParallelStreamFailure {
    public static void main(String[] a) {
        List<Integer> ids = IntStream.range(0, 10000).boxed().collect(Collectors.toList());
        try {
            List<Integer> r = ids.parallelStream().map(i -> { if (i == 100) throw new IllegalStateException("bad file " + i); return i; }).collect(Collectors.toList());
            System.out.println("finished " + r.size());
        } catch (RuntimeException e) { System.out.println("Pipeline aborted, no summary produced: " + e); }
    }
}
