import java.util.*;
/** Q4 - Version 1: stations by extending Thread. */
public class StationThread extends Thread {
    private final int scripts; int scanned;
    StationThread(String name, int scripts) { super(name); this.scripts = scripts; }
    @Override public void run() {
        try {
            for (int i = 0; i < scripts; i++) { Thread.sleep(10 + new Random().nextInt(15)); scanned++; }
        } catch (InterruptedException e) { return; }
        System.out.println(getName() + " finished: " + scanned + " scripts");
    }
    public static void main(String[] args) throws InterruptedException {
        StationThread[] st = new StationThread[4];
        for (int i = 0; i < 4; i++) st[i] = new StationThread("Station-" + (i + 1), 10 + i * 5);
        System.out.println("State before start(): " + st[0].getState() + ", isAlive=" + st[0].isAlive());
        for (StationThread s : st) s.start();
        Thread.sleep(20);
        System.out.println("State while sleeping : " + st[0].getState() + ", isAlive=" + st[0].isAlive());
        int total = 0;
        for (StationThread s : st) { s.join(); total += s.scanned; }      // join waits for each station
        System.out.println("State after join()   : " + st[0].getState() + ", isAlive=" + st[0].isAlive());
        System.out.println("TOTAL scanned = " + total + " (expected 10+15+20+25 = 70)");
    }
}
