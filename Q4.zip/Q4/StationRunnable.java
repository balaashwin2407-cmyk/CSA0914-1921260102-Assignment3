import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
/** Q4 - Version 2: stations by implementing Runnable (task separate from thread). */
public class StationRunnable implements Runnable {
    private final String name; private final int scripts; static final AtomicInteger TOTAL = new AtomicInteger();
    StationRunnable(String name, int scripts) { this.name = name; this.scripts = scripts; }
    @Override public void run() {
        try { for (int i = 0; i < scripts; i++) { Thread.sleep(10 + new Random().nextInt(15)); TOTAL.incrementAndGet(); } }
        catch (InterruptedException e) { return; }
        System.out.println(name + " finished on thread '" + Thread.currentThread().getName() + "'");
    }
    public static void main(String[] args) throws InterruptedException {
        Thread[] t = new Thread[4];
        for (int i = 0; i < 4; i++) t[i] = new Thread(new StationRunnable("Station-" + (i + 1), 10 + i * 5), "T" + (i + 1));
        for (Thread x : t) x.start();
        for (Thread x : t) x.join();
        System.out.println("TOTAL scanned = " + TOTAL.get() + " (expected 70)");
    }
}
