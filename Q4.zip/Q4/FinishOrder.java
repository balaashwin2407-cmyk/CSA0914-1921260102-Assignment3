import java.util.*;
import java.util.concurrent.*;
/** Q4 Student B - record the finishing order over 12 runs (random per-script scan time). */
public class FinishOrder {
    public static void main(String[] args) throws Exception {
        Map<String,Integer> freq = new TreeMap<>();
        for (int run = 1; run <= 12; run++) {
            List<String> order = new CopyOnWriteArrayList<>();
            Thread[] t = new Thread[4];
            for (int i = 0; i < 4; i++) {
                final String n = "S" + (i + 1);
                t[i] = new Thread(() -> {
                    Random rnd = new Random();
                    try { for (int k = 0; k < 8; k++) Thread.sleep(5 + rnd.nextInt(10)); } catch (InterruptedException e) {}
                    order.add(n);
                });
            }
            for (Thread x : t) x.start();
            for (Thread x : t) x.join();
            System.out.println("Run " + String.format("%2d", run) + " finish order: " + order);
            freq.merge(order.toString(), 1, Integer::sum);
        }
        System.out.println("Distinct orders seen: " + freq.size() + " out of 12 runs");
    }
}
