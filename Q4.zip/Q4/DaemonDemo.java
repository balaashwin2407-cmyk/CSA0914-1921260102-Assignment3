/** Q4 Student B - a daemon station does not keep the JVM alive. */
public class DaemonDemo {
    public static void main(String[] args) throws InterruptedException {
        Thread normal = new Thread(() -> { sleep(300); System.out.println("normal station finished"); }, "normal");
        Thread daemon = new Thread(() -> { sleep(2000); System.out.println("daemon station finished"); }, "daemon");
        daemon.setDaemon(true);
        normal.start(); daemon.start();
        System.out.println("main() ending; daemon.isDaemon()=" + daemon.isDaemon());
    }
    static void sleep(long ms) { try { Thread.sleep(ms); } catch (InterruptedException e) {} }
}
