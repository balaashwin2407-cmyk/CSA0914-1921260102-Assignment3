/** Q4 Student A - run() vs start(): which thread executes the body? */
public class RunVsStart {
    public static void main(String[] args) throws InterruptedException {
        Runnable r = () -> System.out.println("  body executed by thread: " + Thread.currentThread().getName());
        Thread a = new Thread(r, "station-A");
        System.out.println("Calling a.run():");  a.run();         // ordinary method call on main
        Thread b = new Thread(r, "station-B");
        System.out.println("Calling b.start():"); b.start(); b.join();
    }
}
