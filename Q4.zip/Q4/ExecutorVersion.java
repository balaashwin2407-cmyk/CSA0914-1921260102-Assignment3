import java.util.*;
import java.util.concurrent.*;
/** Q4 Alternative: fixed thread pool. 4 stations x 100 batches of scripts, each script takes 2 ms. */
public class ExecutorVersion {
    static int scanBatch(int scripts) throws InterruptedException { for (int i = 0; i < scripts; i++) Thread.sleep(2); return scripts; }
    public static void main(String[] args) throws Exception {
        int batches = 40, per = 10;   // n = 400 scripts
        for (int p : new int[]{1, 2, 4, 8}) {
            ExecutorService ex = Executors.newFixedThreadPool(p);
            long t0 = System.nanoTime();
            List<Future<Integer>> fs = new ArrayList<>();
            for (int b = 0; b < batches; b++) fs.add(ex.submit(() -> scanBatch(per)));
            int total = 0; for (Future<Integer> f : fs) total += f.get();
            ex.shutdown();
            System.out.printf("pool=%d  total=%d  time=%5d ms  (ideal n*2ms/p = %d ms)%n", p, total, (System.nanoTime() - t0) / 1_000_000, 400 * 2 / p);
        }
    }
}
