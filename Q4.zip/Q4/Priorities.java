import java.util.*;
import java.util.concurrent.*;
/** Q4 Student B - do priorities change the finishing order? CPU-bound work so the scheduler matters. */
public class Priorities {
    static volatile long sink;
    public static void main(String[] args) throws Exception {
        for (int run = 1; run <= 5; run++) {
            List<String> order = new CopyOnWriteArrayList<>();
            Thread[] t = new Thread[4]; int[] prio = {Thread.MIN_PRIORITY, 3, 7, Thread.MAX_PRIORITY};
            for (int i = 0; i < 4; i++) {
                final String n = "S" + (i + 1) + "(p" + prio[i] + ")";
                t[i] = new Thread(() -> { long x = 0; for (long k = 0; k < 150_000_000L; k++) x += k ^ (x >>> 3); sink = x; order.add(n); });
                t[i].setPriority(prio[i]);
            }
            for (Thread x : t) x.start();
            for (Thread x : t) x.join();
            System.out.println("Run " + run + ": " + order);
        }
    }
}
