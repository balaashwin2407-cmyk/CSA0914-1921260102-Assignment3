import java.util.concurrent.*;
import java.util.concurrent.locks.*;
/** Q6 Alternatives: ArrayBlockingQueue(5) instead of wait/notify; tryLock(timeout) instead of lock ordering. */
public class Q6Alternatives {
    static class Acc { final int id; int bal = 1000; final ReentrantLock lock = new ReentrantLock(); Acc(int i) { id = i; } }
    static boolean transfer(Acc f, Acc t, int amt) throws InterruptedException {
        for (int attempt = 0; attempt < 10; attempt++) {
            if (f.lock.tryLock(20, TimeUnit.MILLISECONDS)) {
                try {
                    if (t.lock.tryLock(20, TimeUnit.MILLISECONDS)) {
                        try { f.bal -= amt; t.bal += amt; return true; } finally { t.lock.unlock(); }
                    }
                } finally { f.lock.unlock(); }
            }
            Thread.sleep(ThreadLocalRandom.current().nextInt(1, 5));   // back off, then retry
        }
        return false;
    }
    public static void main(String[] args) throws Exception {
        // --- producer/consumer with ArrayBlockingQueue ---
        ArrayBlockingQueue<Integer> q = new ArrayBlockingQueue<>(5);
        int[] sum = new int[2];
        Thread cook = new Thread(() -> { try { for (int t = 1; t <= 20; t++) q.put(t); } catch (InterruptedException e) {} });
        Thread[] st = new Thread[2];
        for (int s = 0; s < 2; s++) { final int id = s; st[s] = new Thread(() -> { try { for (int k = 0; k < 10; k++) sum[id] += q.take(); } catch (InterruptedException e) {} }); }
        cook.start(); st[0].start(); st[1].start(); cook.join(); st[0].join(); st[1].join();
        System.out.println("ArrayBlockingQueue sum = " + (sum[0] + sum[1]) + " (expected 210)");

        // --- throughput: 1,000,000 items through wait/notify buffer vs ArrayBlockingQueue ---
        int N = 1_000_000;
        for (int rep = 0; rep < 3; rep++) {
            TokenCounterBench tc = new TokenCounterBench();
            long t0 = System.nanoTime();
            Thread p = new Thread(() -> { try { for (int i = 0; i < N; i++) tc.put(i); } catch (InterruptedException e) {} });
            Thread c = new Thread(() -> { try { for (int i = 0; i < N; i++) tc.take(); } catch (InterruptedException e) {} });
            p.start(); c.start(); p.join(); c.join();
            long t1 = System.nanoTime();
            ArrayBlockingQueue<Integer> bq = new ArrayBlockingQueue<>(5);
            Thread p2 = new Thread(() -> { try { for (int i = 0; i < N; i++) bq.put(i); } catch (InterruptedException e) {} });
            Thread c2 = new Thread(() -> { try { for (int i = 0; i < N; i++) bq.take(); } catch (InterruptedException e) {} });
            p2.start(); c2.start(); p2.join(); c2.join();
            long t2 = System.nanoTime();
            System.out.printf("rep %d: wait/notifyAll %6.0f ns per item   ArrayBlockingQueue %6.0f ns per item%n", rep + 1, (t1 - t0) / (double) N, (t2 - t1) / (double) N);
        }

        // --- the DEADLOCK-PRONE pair, now with tryLock(timeout) ---
        Acc a = new Acc(1), b = new Acc(2);
        int[] ok = new int[2];
        Thread x = new Thread(() -> { try { ok[0] = transfer(a, b, 100) ? 1 : 0; } catch (InterruptedException e) {} });
        Thread y = new Thread(() -> { try { ok[1] = transfer(b, a, 50) ? 1 : 0; } catch (InterruptedException e) {} });
        x.start(); y.start(); x.join(); y.join();
        System.out.println("tryLock transfers completed: " + ok[0] + "," + ok[1] + "  balances " + a.bal + " / " + b.bal + " (expected 950 / 1050), no deadlock");
        // per-transfer cost (uncontended)
        Acc p = new Acc(3), q2 = new Acc(4); int M = 1_000_000; long t0 = System.nanoTime();
        for (int i = 0; i < M; i++) transfer(p, q2, 1);
        long t1 = System.nanoTime();
        Object lockA = new Object(), lockB = new Object(); int[] bal = {0, 0};
        for (int i = 0; i < M; i++) synchronized (lockA) { synchronized (lockB) { bal[0]--; bal[1]++; } }
        long t2 = System.nanoTime();
        System.out.printf("uncontended transfer: tryLock %.0f ns   ordered synchronized %.0f ns%n", (t1 - t0) / (double) M, (t2 - t1) / (double) M);
    }
    static class TokenCounterBench {
        private final int[] buf = new int[5]; private int count, in, out;
        synchronized void put(int t) throws InterruptedException { while (count == 5) wait(); buf[in] = t; in = (in + 1) % 5; count++; notifyAll(); }
        synchronized int take() throws InterruptedException { while (count == 0) wait(); int t = buf[out]; out = (out + 1) % 5; count--; notifyAll(); return t; }
    }
}
