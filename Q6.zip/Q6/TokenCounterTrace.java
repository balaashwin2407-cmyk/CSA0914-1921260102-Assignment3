/** Q6 Student A - record the counter size after every put/take; it must stay in [0,5]. */
public class TokenCounterTrace {
    private final int[] buffer = new int[5]; private int count, in, out;
    int min = 99, max = -1; final StringBuilder log = new StringBuilder();
    synchronized void put(int t) throws InterruptedException {
        while (count == 5) wait();
        buffer[in] = t; in = (in + 1) % 5; count++; record("P" + t);
        notifyAll();
    }
    synchronized int take() throws InterruptedException {
        while (count == 0) wait();
        int t = buffer[out]; out = (out + 1) % 5; count--; record("T" + t);
        notifyAll(); return t;
    }
    private void record(String ev) { min = Math.min(min, count); max = Math.max(max, count); log.append(ev).append("->").append(count).append(' '); }
    public static void main(String[] args) throws Exception {
        TokenCounterTrace c = new TokenCounterTrace(); int[] sum = new int[2];
        Thread cook = new Thread(() -> { try { for (int t = 1; t <= 20; t++) { c.put(t); if (t % 7 == 0) Thread.sleep(5); } } catch (InterruptedException e) {} });
        Thread[] st = new Thread[2];
        for (int s = 0; s < 2; s++) { final int id = s; st[s] = new Thread(() -> { try { for (int k = 0; k < 10; k++) { sum[id] += c.take(); Thread.sleep(2 + id * 3); } } catch (InterruptedException e) {} }); }
        cook.start(); st[0].start(); st[1].start(); cook.join(); st[0].join(); st[1].join();
        System.out.println("Event -> counter size after event:\n" + c.log);
        System.out.println("\nmin size seen = " + c.min + ", max size seen = " + c.max + ", final = " + c.count + ", sum = " + (sum[0] + sum[1]));
    }
}
