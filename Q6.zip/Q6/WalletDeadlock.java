import java.lang.management.*;
/** Q6 Part A - hostel wallet transfers: deadlock demo, detection and lock-ordering fix. */
public class WalletDeadlock {
    static class Account {
        final int id; int balance; Account(int id, int b) { this.id = id; balance = b; }
    }
    static void unsafeTransfer(Account from, Account to, int amt) {
        synchronized (from) {
            pause(100);                                   // widen the window so deadlock is reliable
            synchronized (to) { from.balance -= amt; to.balance += amt; }
        }
    }
    static void safeTransfer(Account from, Account to, int amt) {
        Account first = from.id < to.id ? from : to, second = first == from ? to : from;   // global lock order by id
        synchronized (first) {
            pause(100);
            synchronized (second) { from.balance -= amt; to.balance += amt; }
        }
    }
    static void pause(long ms) { try { Thread.sleep(ms); } catch (InterruptedException e) {} }

    public static void main(String[] args) throws Exception {
        Account a = new Account(1, 1000), b = new Account(2, 1000);
        System.out.println("=== Part A1: transfers without lock ordering ===");
        Thread t1 = new Thread(() -> unsafeTransfer(a, b, 100), "Transfer-A-to-B");
        Thread t2 = new Thread(() -> unsafeTransfer(b, a, 50), "Transfer-B-to-A");
        t1.setDaemon(true); t2.setDaemon(true); t1.start(); t2.start();
        pause(1000);
        ThreadMXBean mx = ManagementFactory.getThreadMXBean();
        long[] ids = mx.findDeadlockedThreads();
        System.out.println("Deadlock detected: " + (ids != null) + (ids == null ? "" : " (" + ids.length + " threads)"));
        if (ids != null) for (ThreadInfo ti : mx.getThreadInfo(ids))
            System.out.println("  " + ti.getThreadName() + " is " + ti.getThreadState() + ", waiting for lock held by " + ti.getLockOwnerName());
        System.out.println("t1 alive=" + t1.isAlive() + ", t2 alive=" + t2.isAlive() + "  (neither will ever finish)");

        System.out.println("\n=== Part A2: same two transfers with lock ordering by account id ===");
        Account c = new Account(1, 1000), d = new Account(2, 1000);
        Thread u1 = new Thread(() -> safeTransfer(c, d, 100)), u2 = new Thread(() -> safeTransfer(d, c, 50));
        u1.start(); u2.start(); u1.join(2000); u2.join(2000);
        System.out.println("Finished: " + (!u1.isAlive() && !u2.isAlive()) + ", balances = " + c.balance + " / " + d.balance + " (expected 950 / 1050)");

        System.out.println("\n=== Stress: 200 random transfers among 5 accounts, ordered locks ===");
        Account[] acc = new Account[5]; for (int i = 0; i < 5; i++) acc[i] = new Account(i, 1000);
        Thread[] th = new Thread[200];
        for (int i = 0; i < th.length; i++) { final int f = i % 5, to = (i * 3 + 1) % 5 == f ? (f + 1) % 5 : (i * 3 + 1) % 5;
            th[i] = new Thread(() -> safeTransfer(acc[f], acc[to], 10)); }
        long t0 = System.nanoTime(); for (Thread t : th) t.start(); for (Thread t : th) t.join();
        int total = 0; for (Account x : acc) total += x.balance;
        System.out.println("All 200 threads finished in " + (System.nanoTime() - t0) / 1_000_000 + " ms; total money = " + total + " (expected 5000)");
    }
}
