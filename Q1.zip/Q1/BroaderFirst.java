import java.io.*;
/** Q1 Student B - broader catch before narrower: this does NOT compile. */
public class BroaderFirst {
    public static void main(String[] args) {
        try {
            new FileReader("x.txt");
        } catch (IOException e) {
            System.out.println("broad");
        } catch (FileNotFoundException e) {      // unreachable: already handled by IOException
            System.out.println("narrow");
        }
    }
}
