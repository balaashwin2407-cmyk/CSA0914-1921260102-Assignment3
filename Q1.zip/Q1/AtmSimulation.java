import java.io.*;
import java.util.*;

/** Q1 - ATM withdrawal using try / multi-catch / finally. */
public class AtmSimulation {
    static final Map<String, Integer> BALANCES = new HashMap<>();
    static int finallyCount = 0;

    static void readCard(String cardFile) throws IOException {      // FileNotFoundException is a checked IOException
        try (BufferedReader r = new BufferedReader(new FileReader(cardFile))) {
            r.readLine();
        }
    }

    /** Returns a short description of the path taken, so tests can be tabulated. */
    static String withdraw(String cardFile, String account, String amountText) {
        String path;
        System.out.println("  -> input: card=" + cardFile + ", account=" + account + ", amount=" + amountText);
        try {
            readCard(cardFile);                                       // may throw FileNotFoundException
            int amount = Integer.parseInt(amountText.trim());         // NumberFormatException / NullPointerException
            if (amount <= 0) throw new IllegalArgumentException("Amount must be positive");
            Integer balance = BALANCES.get(account);
            if (balance == null) throw new AccountNotFoundException("No account " + account);
            if (amount > balance) throw new InsufficientFundsException("Requested " + amount + " but balance is " + balance);
            BALANCES.put(account, balance - amount);
            System.out.println("  SUCCESS: dispensed " + amount + ", new balance " + BALANCES.get(account));
            path = "no exception";
        } catch (NumberFormatException | NullPointerException e) {    // multi-catch: unrelated siblings; narrower than IAE so it goes first
            System.out.println("  catch#1 (multi-catch): invalid amount -> " + e.getClass().getSimpleName());
            path = "catch#1 multi-catch NFE|NPE";
        } catch (IllegalArgumentException e) {                         // broader parent of NumberFormatException, so it comes after
            System.out.println("  catch#2: bad value -> " + e.getMessage());
            path = "catch#2 IllegalArgumentException";
        } catch (InsufficientFundsException e) {
            System.out.println("  catch#3: " + e.getMessage());
            path = "catch#3 InsufficientFunds";
        } catch (AccountNotFoundException e) {
            System.out.println("  catch#4: " + e.getMessage());
            path = "catch#4 AccountNotFound";
        } catch (IOException e) {
            System.out.println("  catch#5: card reader problem -> " + e.getClass().getSimpleName());
            path = "catch#5 IOException (FileNotFound)";
        } finally {
            finallyCount++;
            System.out.println("  finally: card ejected, session closed (#" + finallyCount + ")");
        }
        return path;
    }

    public static void main(String[] args) throws Exception {
        BALANCES.put("1001", 5000);
        File card = File.createTempFile("card", ".dat");
        card.deleteOnExit();
        try (FileWriter w = new FileWriter(card)) { w.write("1001\n"); }
        String c = card.getPath();

        String[][] tests = {
            {"T1 valid withdrawal",        c, "1001", "2000"},
            {"T2 letters in amount",       c, "1001", "abc"},
            {"T3 negative amount",         c, "1001", "-500"},
            {"T4 amount > balance",        c, "1001", "99999"},
            {"T5 card file missing",       "/no/such/card.dat", "1001", "100"},
            {"T6 unknown account",         c, "9999", "100"},
            {"T7 null amount (NPE)",       c, "1001", null},
        };
        List<String[]> table = new ArrayList<>();
        for (String[] t : tests) {
            System.out.println(t[0]);
            String p = withdraw(t[1], t[2], t[3]);
            table.add(new String[]{t[0], p});
        }
        System.out.println("\n===== TEST TABLE =====");
        for (String[] r : table) System.out.printf("%-26s | %-36s | finally ran: yes%n", r[0], r[1]);
        System.out.println("finally executed " + finallyCount + " times for " + tests.length + " inputs");
    }
}

class InsufficientFundsException extends Exception {          // checked (business rule)
    InsufficientFundsException(String m) { super(m); }
}
class AccountNotFoundException extends Exception {           // checked
    AccountNotFoundException(String m) { super(m); }
}

