import java.util.*;
/** Q1 Alternative: no exceptions - pre-check everything and return error codes. */
public class ErrorCodeVersion {
    static final Map<String,Integer> BAL = new HashMap<>(Map.of("1001", 5000));
    // -1 invalid number, -2 non-positive, -3 no account, -4 insufficient
    static int withdraw(String acct, String amountText) {
        Scanner sc = new Scanner(amountText);
        if (!sc.hasNextInt()) return -1;
        int amt = sc.nextInt();
        if (amt <= 0) return -2;
        Integer b = BAL.get(acct);
        if (b == null) return -3;
        if (amt > b) return -4;
        BAL.put(acct, b - amt);
        return amt;
    }
    public static void main(String[] a) {
        for (String s : new String[]{"2000","abc","-5","99999"}) System.out.println(s + " -> " + withdraw("1001", s));
    }
}
