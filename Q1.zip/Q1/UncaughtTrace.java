/** Q1 Student B - an uncaught exception and its stack trace. */
public class UncaughtTrace {
    static int parseAmount(String s) { return Integer.parseInt(s); }
    static void withdraw(String s)   { int a = parseAmount(s); System.out.println(a); }
    public static void main(String[] args) {
        withdraw("abc");              // nobody catches this
    }
}
