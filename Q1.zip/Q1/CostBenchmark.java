/** Q1 Alternative: cost of throw/catch vs returning an error code (own measurement). */
public class CostBenchmark {
    static int codeVersion(String s) {
        if (s.isEmpty() || !Character.isDigit(s.charAt(0))) return -1;
        return Integer.parseInt(s);
    }
    static int excVersion(String s) {
        try { return Integer.parseInt(s); } catch (NumberFormatException e) { return -1; }
    }
    static class Light extends RuntimeException {   // no stack trace captured
        Light() { super(null, null, false, false); }
    }
    static int lightVersion(String s) {
        try { if (!Character.isDigit(s.charAt(0))) throw new Light(); return Integer.parseInt(s); }
        catch (Light e) { return -1; }
    }
    public static void main(String[] args) {
        int N = 2_000_000; long sink = 0;
        for (int w = 0; w < 3; w++) { for (int i = 0; i < 200000; i++) { sink += codeVersion("abc") + excVersion("abc") + lightVersion("abc"); } }
        long t0 = System.nanoTime(); for (int i = 0; i < N; i++) sink += codeVersion("abc");
        long t1 = System.nanoTime(); for (int i = 0; i < N; i++) sink += excVersion("abc");
        long t2 = System.nanoTime(); for (int i = 0; i < N; i++) sink += lightVersion("abc");
        long t3 = System.nanoTime();
        System.out.printf("Error-code (invalid input) : %8.1f ns/op%n", (t1 - t0) / (double) N);
        System.out.printf("Exception with stack trace  : %8.1f ns/op%n", (t2 - t1) / (double) N);
        System.out.printf("Exception w/o stack trace   : %8.1f ns/op%n", (t3 - t2) / (double) N);
        long u0 = System.nanoTime(); for (int i = 0; i < N; i++) sink += codeVersion("123");
        long u1 = System.nanoTime(); for (int i = 0; i < N; i++) sink += excVersion("123");
        long u2 = System.nanoTime();
        System.out.printf("Valid input, code check     : %8.1f ns/op%n", (u1 - u0) / (double) N);
        System.out.printf("Valid input, try/catch      : %8.1f ns/op%n", (u2 - u1) / (double) N);
        System.out.println("(sink=" + sink + ")");
    }
}
